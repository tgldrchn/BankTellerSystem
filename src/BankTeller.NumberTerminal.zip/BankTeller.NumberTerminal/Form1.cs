using BankTeller.Core.Models;
using BankTeller.NumberTerminal.Services;

namespace BankTeller.NumberTerminal;

public partial class Form1 : Form
{
    private readonly IQueueClient _queueClient;
    private readonly TicketPdfService _ticketPdfService;

    public Form1()
    {
        InitializeComponent();

        // API бэлэн биш үед:
        _queueClient = new MockQueueService();

        // API бэлэн болсон үед дээрхийг үүгээр солино:
        // _queueClient = new ApiQueueService();

        _ticketPdfService = new TicketPdfService();

        lblTicketNumber.Text = "---";
        lblMessage.Text = "Дугаар авах товчийг дарна уу.";
        lblPrintPreview.Text = "Тасалбарын мэдээлэл энд харагдана.";
    }

    private async void btnIssueTicket_Click(object sender, EventArgs e)
    {
        try
        {
            btnIssueTicket.Enabled = false;
            lblMessage.Text = "Дараагийн дугаарыг авч байна...";

            var ticket = await _queueClient.IssueTicketAsync();

            ShowTicket(ticket);

            var pdfPath = _ticketPdfService.GenerateTicketPdf(ticket);

            lblMessage.Text = "Дугаар амжилттай үүслээ. PDF хэвлэх файл бэлэн боллоо.";

            MessageBox.Show(
                $"Дугаар амжилттай үүслээ.\n\nPDF файл:\n{pdfPath}",
                "Амжилттай",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Дугаар авах үед алдаа гарлаа.";
            MessageBox.Show(ex.Message, "Алдаа", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            btnIssueTicket.Enabled = true;
        }
    }

    private void ShowTicket(QueueTicket ticket)
    {
        var ticketNumber = $"A-{ticket.Number:D3}";
        var issuedTime = ticket.IssuedAt.ToLocalTime();

        lblTicketNumber.Text = ticketNumber;

        lblPrintPreview.Text =
$"""
========================
      BANK TELLER
========================

Таны дугаар:

      {ticketNumber}

Огноо: {issuedTime:yyyy-MM-dd}
Цаг:   {issuedTime:HH:mm:ss}

Төлөв: Хүлээж байна
========================
Дэлгэц дээр дугаараа хүлээнэ үү.
""";
    }
}